using UnityEngine;
using UnityEngine.SceneManagement;

public class SimpleMoveController : MonoBehaviour
{
    public Animator myAnimator;
    public int speed = 5;
    public float jumpForce = 100f;
    public bool isJumping = false;
  
    private Rigidbody2D rb;
    private GameObject currentpotal, currentPotal1, currentPotal2;
    

    private void Start()
    {
        myAnimator.SetBool("move", false);
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        float direction = Input.GetAxis("Horizontal");

        if (direction > 0)
        {
            transform.localScale = new Vector3(0.8f, 0.8f, 1);
            myAnimator.SetBool("move", true);
        }
        else if (direction < 0)
        {
            transform.localScale = new Vector3(-0.8f, 0.8f, 1);
            myAnimator.SetBool("move", true);
        }
        else
        {
            myAnimator.SetBool("move", false);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (!isJumping)
            {
                Jump();
            }
        }

       

        if (Input.GetKeyDown(KeyCode.F))
        {
            if (currentpotal != null)
            {
                SceneManager.LoadScene("DoorScene");
            }

            if (currentPotal1 != null)
            {
                SceneManager.LoadScene("DoorScene1");
            }
            if (currentPotal2 != null)
            {
                SceneManager.LoadScene("MainScene");
            }
        }

        transform.Translate(Vector3.right * direction * speed * Time.deltaTime);
    }

   
    
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground"))
        {
            isJumping = false;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Potal"))
        {
            currentpotal = collision.gameObject;
        }
        else if (collision.CompareTag("Potal1"))
        {
            currentPotal1 = collision.gameObject;
        }
        else if (collision.CompareTag("Potal2"))
        {
            currentPotal2 = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Potal"))
        {
            if (collision.gameObject == currentpotal)
            {
                currentpotal = null;
            }
        }
        else if (collision.CompareTag("Potal1"))
        {
            if (collision.gameObject == currentpotal)
            {
                currentPotal1 = null;
            }
        }
        else if (collision.CompareTag("Potal2"))
        {
            if (collision.gameObject == currentpotal)
            {
                currentPotal2 = null;
            }
        }
    }

    void Jump()
    {
        isJumping = true;
        rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}
